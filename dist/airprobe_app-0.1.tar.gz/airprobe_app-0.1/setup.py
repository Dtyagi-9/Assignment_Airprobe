from setuptools import setup 
setup(name="airprobe_app",version="0.1",description="A command line application that fetches weather information from Windy.com",author="Dev Tyagi",packages=["airprobe_app"]
,install_requires=["requests","datetime"])